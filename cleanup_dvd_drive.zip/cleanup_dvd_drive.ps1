﻿Configuration DriveLetter
{
  param ($MachineName)

  Node $MachineName
  {
	Script ConfigureDVDDrive { 
		SetScript = { 
			# Check availability of drive letter and remap dvd drive if needed
    $dvdDrive = Get-WmiObject win32_logicaldisk -filter 'DriveType=5'
    if ($dvdDrive.DeviceId -ne "y:")
    {
        $a = mountvol $dvdDrive.DeviceID /l
        mountvol $dvdDrive.DeviceID /d
        $a = $a.Trim()
        mountvol "Y:" $a
    }
    } 
   }   
  }
} 

